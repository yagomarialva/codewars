import ESDTable from "../../../pages/ESD/Stations/ESDTable/ESDTable";

function StationList() {
  return <ESDTable></ESDTable>;
}

export default StationList;
