import OperatorTable from "../../../pages/ESD/Operator/OperatorTable/OperatorTable";

function Operators() {
    return <OperatorTable></OperatorTable>
  }
  
  export default Operators;
  