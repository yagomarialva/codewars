import MonitorTable from "../../../pages/ESD/Monitor/MonitorTable/MonitorTable";

function Monitors() {
    return <MonitorTable></MonitorTable>
  }
  
  export default Monitors;
  